-----------------------
Christopher Wood
Project 2 - TFTP client
-----------------------

Usage: 

1. The program can be built by running 'javac *.java'.

2. The usage of the program is as outlined in the project writeup:

	java TFTPreader [netascii|octet] 

Notes:

1. No conversion was done to handle platform-independent line endings
when transferring in netascii.

